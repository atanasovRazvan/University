function p = Newton(f,J,x0,tol)

xold=x0;
xnew=x0-J(x0)^(-1)*(f(x0));
while norm(xnew-xold)>tol
    xold=xnew;
    xnew=xold-J(xold)^(-1)*f(xold);
end
p=xnew;
end