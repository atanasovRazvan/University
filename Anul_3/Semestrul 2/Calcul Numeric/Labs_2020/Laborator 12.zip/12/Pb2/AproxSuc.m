function X=AproxSuc(f,J,x0,epsilon,N)

i=1;
lambda=-J(x0)^(-1);
while (i<=N)
    x1=x0+(lambda*f(x0))';
    if abs(x1-x0)<epsilon
        X=x1;
        return
    end
    i=i+1;
    x0=x1;
end