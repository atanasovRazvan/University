f = @(x) sqrt(10/(x+4));
Steffensen(f,1.5,1e-3,0,50)

f2 = @(x) cos(x) - x;
Secanta(f2,0.5,pi/4)

fd = @(x) -sin(x) - 1;
NewtonRaphson(f2,fd,pi/4)