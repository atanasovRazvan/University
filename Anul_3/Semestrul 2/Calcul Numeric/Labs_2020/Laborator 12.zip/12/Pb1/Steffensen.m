function [pf]=Steffensen(f,x0,ea,er,nmax)

if nargin < 6, nmax=50; end
if nargin < 5, er=0; end
if nargin < 4, ea=1e-3; end
p0=x0;
for i = 1 : nmax
    p1 = f(p0);
    p2 = f(p1);
    p = p0 - ((p1-p0)^2)/(p2 - 2*p1 + p0);
    if abs(p-p0)<ea+er*abs(p)
        pf=p;
        return
    end
    p0=p;
end
error('S-a depasit numarul maxim de iteratii')