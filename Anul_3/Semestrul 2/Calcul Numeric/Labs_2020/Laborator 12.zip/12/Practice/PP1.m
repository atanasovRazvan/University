addpath(genpath('../Pb2'))
format long;
f = @(x) [x(1)^2 + x(2)^2 - 1; x(1)^3 - x(2)];
fd = @(x) [2*x(1), 2*x(2); 3*x(1)^2, -1];
x0 = [1;1];

Newton(f,fd,x0,1e-7)