addpath(genpath('../Pb1'))

adaptare = adapt(@sin, 0, pi, 0.00001, @Trapez)
adaptare2 = adapt(@sin, 0, pi, 0.0000001, @Dreptunghi)
adaptare3 = adapt(@sin, 0, pi, 0.00001, @Simpson)