addpath(genpath('../Pb1'))
f1 = @(x) exp(-x.^2) .* sin(x);
f2 = @(x) exp(-x.^2) .* cos(x);
[x,A] = Gauss_Hermite(10000);
rez1 = A * f1(x)
rez2 = A * f2(x)