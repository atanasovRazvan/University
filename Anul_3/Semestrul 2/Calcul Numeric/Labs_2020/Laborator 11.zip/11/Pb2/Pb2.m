addpath(genpath('../Pb1'))
f = @(x) sin(x.^2);
q = quad(f,-1,1)
ql = quadl(f,-1,1)
[x,A] = Gauss_Legendre(10)
rez = A * f(x)