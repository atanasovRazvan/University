#pragma once

//Modul pentru teste

void testEntity();
void testValidator();
void testDynamicVect();
void testService();
void testFunctions();