# Aplicatie-cofetarie
Aplicatie care permite gestiunea stocului de materii prime folosite intr-o cofetarie.
